<?php

require_once __DIR__ . '/faqs.php';
require_once __DIR__ . '/text-image.php';
require_once __DIR__ . '/benefits-list.php';
require_once __DIR__ . '/integration-list.php';
require_once __DIR__ . '/documentation.php';